fitL <- lme(score_tr ~ t + I((treatment=="OffSOnM")) + I((treatment=="OnSOffM")) + I((treatment=="OnSOnM"))
            + I((treatment=="OffSOnM")*t) + I((treatment=="OnSOffM")*t) + I((treatment=="OnSOnM")*t)
            + akinesiaOff_Intake + rigidityOff_Intake + tremorOff_Intake + axeOff_Intake + 
              duration + doparesponse,
            random = ~ t|id, data = data)  
fitS <- coxph(Surv(survival,deceased) ~ hallucinations_Intake + sex + ageDebut + akinesiaOff_Intake + rigidityOff_Intake + tremorOff_Intake + axeOff_Intake + 
                duration + doparesponse, data = data.id, x = TRUE)

# fitL <- lme(score_tr ~ t + I((treatment=="OffSOnM")) + I((treatment=="OnSOffM")) + I((treatment=="OnSOnM"))
#               + I((treatment=="OffSOnM")*t) + I((treatment=="OnSOffM")*t) + I((treatment=="OnSOnM")*t),
#             random = ~ t|id, data = data)  
# fitS <- coxph(Surv(survival,deceased) ~ 1, data = data.id, x = TRUE)
fitJB <- jointModelBayes(fitL, fitS, timeVar = "t",control=list(n.burnin=10000,n.iter=60000,adapt=TRUE))
summary(fitJB)


df <- with(data,expand.grid(
  t = seq(min(t),max(t),length=30),
  treatment = levels(treatment),
  ageAtIntervention = median(ageAtIntervention),
  duration = median(duration),
  doparesponse = median(doparesponse),
  sex = levels(sex),
  updrsI_Intake = median(updrsI_Intake),
  updrsIIOff_Intake = median(updrsIIOff_Intake),
  akinesiaOff_Intake = median(akinesiaOff_Intake),
  rigidityOff_Intake = median(rigidityOff_Intake),
  tremorOff_Intake = median(tremorOff_Intake),
  axeOff_Intake = median(axeOff_Intake),
  updrsIV_Intake = median(updrsIV_Intake),
  fallsOff_Intake = median(fallsOff_Intake),
  fallsOn_Intake = median(fallsOn_Intake),
  swallowingOff_Intake = median(swallowingOff_Intake)
))

p <- predict(fitJB,newdata=df,interval="confidence",return=TRUE)
#xyplot(pred + low + upp ~ t | treatment,data=p,type="l")
xyplot(pred^2+ low^2 + upp^2~t,data=p)
