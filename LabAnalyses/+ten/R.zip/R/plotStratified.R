# Stratify by death, using raw scores
df = data
df$t2 <- -(df$survival - df$t)
if("treatment" %in% colnames(df)) {
  df <- df[df$treatment=="OffSOffM",]
}

a <- ggplot(data = df, aes(x = t2, y = score, col=factor(deceased)))
a <- a + stat_smooth(method = "lm", formula=y~poly(x,1)) + geom_point()
#a <- a + stat_smooth(method = "loess",span = 2) + geom_point()
a

# Stratify by death, using predicted scores
p <- predict(fitJ,newdata=data,interval="confidence",return=TRUE)
p$t2 <- -(p$survival - p$t)
if("treatment" %in% colnames(p)) {
  p <- p[p$treatment=="OffSOffM",]  
}

a <- ggplot(data = p, aes(x = t2, y = pred^2, col=factor(deceased)))
a <- a + stat_smooth(method = "lm", formula=y~poly(x,3)) + geom_point()
#a <- a + stat_smooth(method = "loess",span = 2) + geom_point()
a