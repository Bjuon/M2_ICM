scores = c("ldopaEquiv","hallucinations","updrsI","updrsII","updrsIII","akinesia","rigidity","tremor","axe","Mattis","frontal50","falls")
#scores = c("hallucinations")

for (i in 1:length(scores)) {
  score = scores[i]
  print(score)
  source("/Users/brian/Documents/Code/Repos/LabAnalyses/+ten/R/fitJointModel.R")
  rm("score","fitL","fitS","fitJ","predMarg","predSub","predSurv")
}
