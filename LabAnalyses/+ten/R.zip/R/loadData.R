## longitudinal data
data <- read.csv(paste(basedir,score,".txt",sep=""))
data$id2 = data$id
data <- within(data, {
  #id2 <- id
  id <- as.integer(id)
  score <- as.numeric(score)
  t <- as.numeric(t)/12
  duration <- as.numeric(duration)
  survival <- as.numeric(survival)/12
  ageDebut <- as.numeric(ageDebut)
  ageAtIntervention <- as.numeric(ageAtIntervention)
})

if ((score=="ldopaEquiv")|(score=="hallucinations")|(score=="Mattis")|(score=="frontal50")|(score=="updrsI")) {
  data <- subset(data, select = c("id","score","t",vars))    
} else {
  data <- subset(data, select = c("id","score","treatment","t",vars))  
}

data$score_tr <- data$score
if (score=="Mattis") {
  data <- within(data, {score_tr <- sqrt(144-score) })
} else if (score=="frontal50") {
  data <- within(data, {score_tr <- sqrt(50-score) })
} else if ((score=="ldopaEquiv")|(score=="hallucinations")|(score=="falls")|(score=="updrsI")|(score=="updrsII")|(score=="updrsIII")|(score=="akinesia")|(score=="rigidity")|(score=="axe")|(score=="tremor")) {
  data <- within(data, {score_tr <- sqrt(score) })
}

# Impute missing covariates
set.seed(1234)
temp = hot.deck(data,m=1)
data = temp$data[[1]]

# Construct id dataframe for jointModel
ind = complete.cases(data)
unique(data$id[ind==FALSE])
data = data[ind,]

# Remove one case that causes fit failure (for hallucinations)
if (score=="hallucinations") {
  data = data[c(1:290,292:297),]  
}

# surivival data
data.id = data[!duplicated(data$id),]

