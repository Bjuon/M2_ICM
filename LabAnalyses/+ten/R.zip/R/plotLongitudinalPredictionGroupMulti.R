load("akinesia.RData")
maxval = 35
source("/Users/brian/Documents/Code/Repos/LabAnalyses/+ten/R/plotLongitudinalPredictionGroup.R")
p1 = a

load("rigidity.RData")
maxval = 15
source("/Users/brian/Documents/Code/Repos/LabAnalyses/+ten/R/plotLongitudinalPredictionGroup.R")
p2 = a

load("tremor.RData")
maxval = 10
source("/Users/brian/Documents/Code/Repos/LabAnalyses/+ten/R/plotLongitudinalPredictionGroup.R")
p3 = a

load("axe.RData")
maxval = 15
source("/Users/brian/Documents/Code/Repos/LabAnalyses/+ten/R/plotLongitudinalPredictionGroup.R")
p4 = a

source("/Users/brian/Documents/Code/Repos/LabAnalyses/+ten/R/multiplot.R")
multiplot(p1, p3, p2, p4, cols=2)