require(JM)
require(car)
require(lattice)
require(latticeExtra)
require(ggplot2)
theme_set(theme_bw())
require(plyr)
require(hot.deck)

#score = "axe" # axe, akinesia, tremor, rigidity, updrsIII
vars = c("id2","sex","ageDebut","ageAtIntervention","doparesponse","survival","deceased","duration",
         "akinesiaOff_Intake","rigidityOff_Intake","tremorOff_Intake","axeOff_Intake","updrsIV_Intake",
         "hallucinations_Intake")

basedir = "/Users/brian/CloudStation/Work/Papers/2015_STN10Year/"
setwd(basedir)
source("/Users/brian/Documents/Code/Repos/LabAnalyses/+ten/R/loadData.R")

# sensitivity analysis by removing patients who died from non-Parkinson's disease
#data <- subset(data,(id!="BANC")&(id!="DEON")&(id!="TAYLOR")&(id!="FONTAINE")&(id!="PAUCHARD"))
#data.id <- subset(data.id,(id!="BANC")&(id!="DEON")&(id!="TAYLOR")&(id!="FONTAINE")&(id!="PAUCHARD"))

c = lmeControl(msMaxIter = 20)
if ((score=="ldopaEquiv")|(score=="hallucinations")|(score=="frontal50")|(score=="Mattis")|(score=="updrsI")) {
    fitL <- lme(score_tr ~ t + ageDebut + akinesiaOff_Intake + rigidityOff_Intake + tremorOff_Intake + axeOff_Intake +
                  duration + doparesponse, random = ~ t|id, data = data, control=c)
    fitS <- coxph(Surv(survival,deceased) ~ sex + ageDebut + axeOff_Intake + duration, data = data.id, x = TRUE)
#   fitL <- lme(score_tr ~ t + ageDebut + akinesiaOff_Intake + rigidityOff_Intake + tremorOff_Intake + axeOff_Intake +
#                 duration + doparesponse, random = ~ t|id, data = data, control=c)
#   fitS <- coxph(Surv(survival,deceased) ~ hallucinations_Intake + sex + ageDebut + akinesiaOff_Intake + rigidityOff_Intake + tremorOff_Intake + axeOff_Intake + 
#                   duration + doparesponse, data = data.id, x = TRUE)
#   fitL <- lme(score_tr ~ t + akinesiaOff_Intake + rigidityOff_Intake + tremorOff_Intake + axeOff_Intake + ageAtIntervention +
#               updrsIV_Intake, random = ~ t|id, data = data)
#   fitS <- coxph(Surv(survival,deceased) ~ hallucinations_Intake + sex + ageAtIntervention + axeOff_Intake + duration, data = data.id, x = TRUE)
} else {
  fitL <- lme(score_tr ~ treatment*t + ageDebut + akinesiaOff_Intake + rigidityOff_Intake + tremorOff_Intake + axeOff_Intake + 
                duration + doparesponse,
              random = ~ t|id, data = data, control=c)  
  fitS <- coxph(Surv(survival,deceased) ~ sex + ageDebut + axeOff_Intake + duration, data = data.id, x = TRUE)
#   fitS <- coxph(Surv(survival,deceased) ~ hallucinations_Intake + sex + ageDebut + akinesiaOff_Intake + rigidityOff_Intake + tremorOff_Intake + axeOff_Intake + 
#                   duration + doparesponse, data = data.id, x = TRUE)
#   
#   fitL <- lme(score_tr ~ treatment*t + akinesiaOff_Intake + rigidityOff_Intake + tremorOff_Intake + axeOff_Intake + 
#                 updrsIV_Intake + doparesponse,
#               random = ~ t|id, data = data)  
#   fitS <- coxph(Surv(survival,deceased) ~ hallucinations + sex + ageAtIntervention + axeOff_Intake + duration, data = data.id, x = TRUE)
}
fitJ <- jointModel(fitL, fitS, timeVar="t",method="weibull-PH-GH")
summary(fitJ)

# Marginal and subject-specific predictions for longitudinal part of model
predMarg <- predict(fitJ,newdata=data,type = "Marginal",interval="confidence",return=TRUE)
predSub <- predict(fitJ,newdata=data,type = "Subject",interval="confidence",return=TRUE)
predSub = predSub[1:nrow(predMarg),]

# Predictions of conditional probability of surviving later times than the last observed time
id = data.id$id
n = nrow(data.id)
predSurv = vector("list",n)
for (i in 1:n) {
  set.seed(123)
  predSurv[[i]] <- survfitJM(fitJ,newdata=data[data$id==id[i],],idVar ="id",M = 200)
}

save(score,data,data.id,fitL,fitS,fitJ,predMarg,predSub,predSurv,file=paste(score,".RData",sep=""))
