
dev.off()
par(mfrow = c(5,5))# ,mar=c(1,1,1,1))
for (i in 1:25) {
  plot(predSurv[[i]], include.y = TRUE, add.last.time.axis.tick = TRUE, legend = FALSE,conf.int=TRUE,estimator="both",
       main=paste('id',':',data.id[i,]$id2,as.integer(data.id[i,]$id),', sex:',data.id[i,]$sex,'\nage:',data.id[i,]$ageAtIntervention))
  if(data.id[i,]$deceased==1) {
    abline(v=data.id[i,]$survival,col = "magenta")
  } else {
    abline(v=data.id[i,]$survival,col = "lightgray")
  }
}

dev.off()
par(mfrow = c(7,6))# ,mar=c(1,1,1,1))
for (i in 61:100) {
  if (data.id[i,]$deceased==0) {
    plot(predSurv[[i]], include.y = TRUE, add.last.time.axis.tick = TRUE, legend = FALSE,conf.int=TRUE,estimator="both",
         main=paste('id',':',data.id[i,]$id2,as.integer(data.id[i,]$id),', sex:',data.id[i,]$sex,'\nage:',data.id[i,]$ageAtIntervention))
    if(data.id[i,]$deceased==1) {
      abline(v=data.id[i,]$survival,col = "magenta")
    } else {
      abline(v=data.id[i,]$survival,col = "lightgray")
    }
  }
}
